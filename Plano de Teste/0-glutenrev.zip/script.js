< !DOCTYPE html >
  <html lang="pt-br">
    <head>
      <meta charset="UTF-8">
        <title>Seleção de Estado e Cidade</title>
    </head>
    <body>
      <h1>Selecione o Estado e a Cidade:</h1>
      <form id="filtroForm" onsubmit="filtrarOpcoes(); return false;">
        <label for="estado">Estado:</label>
        <select id="estado" name="estado" onchange="carregarCidades()">
          <option value="selecione">Selecione o estado</option>
          <option value="mg">Minas Gerais</option>
          <option value="sp">São Paulo</option>
          <!-- Adicione mais estados conforme necessário -->
        </select><br><br>
          <label for="cidade">Cidade:</label>
          <select id="cidade" name="cidade">
            <option value="selecione">Selecione a cidade</option>
            <!-- Opções de cidades serão preenchidas dinamicamente -->
          </select><br><br>
            <label for="lugar">Lugar:</label>
            <select id="lugar" name="lugar">
              <option value="selecione">Selecione um lugar</option>
              <!-- Opções de lugares serão preenchidas dinamicamente -->
            </select><br><br>
              <input type="submit" value="Filtrar">
              </form>

              <script>
                var lugaresPorCidade = {
                  'mg': {
                  'belo_horizonte': ['Praça da Liberdade', 'Mercado Central', 'Parque das Mangabeiras'],
                'outra_cidade_mg': ['Lugar 1', 'Lugar 2', 'Lugar 3']
      },
                'sp': {
                  'sao_paulo': ['Ibirapuera', 'Avenida Paulista', 'Parque do Povo'],
                'outra_cidade_sp': ['Lugar A', 'Lugar B', 'Lugar C']
      }
      // Adicione mais lugares conforme necessário para outros estados e cidades
    };

                function carregarCidades() {
      var estadoSelecionado = document.getElementById('estado').value;
                var selectCidade = document.getElementById('cidade');
                selectCidade.innerHTML = '<option value="selecione">Selecione a cidade</option>';

                if (estadoSelecionado !== 'selecione') {
        var cidades = Object.keys(lugaresPorCidade[estadoSelecionado]);
                cidades.forEach(function(cidade) {
          var option = document.createElement('option');
                option.value = cidade;
                option.textContent = cidade.replace('_', ' ');
                selectCidade.appendChild(option);
        });
      }
    }

                function carregarLugares() {
      var estadoSelecionado = document.getElementById('estado').value;
                var cidadeSelecionada = document.getElementById('cidade').value;
                var selectLugar = document.getElementById('lugar');
                selectLugar.innerHTML = '<option value="selecione">Selecione um lugar</option>';

                if (estadoSelecionado !== 'selecione' && cidadeSelecionada !== 'selecione') {
        var lugares = lugaresPorCidade[estadoSelecionado][cidadeSelecionada];
                lugares.forEach(function(lugar) {
          var option = document.createElement('option');
                option.value = lugar.toLowerCase().replace(' ', '_');
                option.textContent = lugar;
                selectLugar.appendChild(option);
        });
      }
    }

                function filtrarOpcoes() {
      var estado = document.getElementById('estado').value;
                var cidade = document.getElementById('cidade').value;
                var lugar = document.getElementById('lugar').value;

                if (estado !== 'selecione' && cidade !== 'selecione' && lugar !== 'selecione') {
        var url = 'opcoes_filtradas.html?estado=' + estado + '&cidade=' + cidade + '&lugar=' + lugar;
                window.location.href = url;
      } else {
                  alert('Por favor, selecione o estado, a cidade e o lugar.');
      }
    }

                document.getElementById('estado').addEventListener('change', carregarCidades);
                document.getElementById('cidade').addEventListener('change', carregarLugares);
              </script>
            </body>
            </html>

