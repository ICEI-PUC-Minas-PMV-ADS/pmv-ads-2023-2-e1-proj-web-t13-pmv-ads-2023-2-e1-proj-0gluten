<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Contas</title>
</head>
<body>
    <h2>Adicionar Contas</h2>

    <form id="formConta">
        <label for="nomeUsuario">Nome de Usuário:</label>
        <input type="text" id="nomeUsuario" required>
        <label for="senha">Senha:</label>
        <input type="password" id="senha" required>
        <button type="submit">Adicionar Conta</button>
    </form>
